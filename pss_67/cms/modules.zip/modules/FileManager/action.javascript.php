<?php
if (!function_exists("cmsms")) exit;

echo $this->_output_header_javascript();

?>